'use strict';
// Local-only SMAT execution bridge. Never expose this server to the public internet.
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { spawn } = require('child_process');
const ROOT = __dirname;
const HOST = '127.0.0.1';
const PORT = Number(process.env.PORT || 8080);
const MAX_BODY = 512 * 1024;
const TIMEOUT_MS = 30000;
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
function send(res, status, data, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(type.startsWith('application/json') ? JSON.stringify(data) : data);
}
function runOctave(code) {
 return new Promise((resolve) => {
   const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'smat-'));
   const scriptPath = path.join(dir, 'main.m');
   const plotPath = path.join(dir, 'smat-plot.png');
   // Append a plot export after the user's script. Errors in user code remain visible in output.
   const wrapper = `1;\ntry\n${code}\ncatch err\n  disp(getReportCompat(err));\n  exit(2);\nend\ntry\n  figs = findall(0, 'type', 'figure');\n  if ~isempty(figs)\n    figure(figs(1)); drawnow(); print('${plotPath.replace(/\\/g,'/')}', '-dpng', '-r120');\n  end\ncatch ploterr\n  disp(['Plot export warning: ', ploterr.message]);\nend\n`;
   // Octave doesn't have MATLAB's getReport; provide a small compatibility helper.
   const fullScript = wrapper.replace("disp(getReportCompat(err));", "disp(err.message);") ;
   fs.writeFileSync(scriptPath, fullScript, 'utf8');
   let stdout = '', stderr = '', settled = false;
   const finish = (result) => { if (settled) return; settled = true; clearTimeout(timer); try { fs.rmSync(dir,{recursive:true,force:true}); } catch {} resolve(result); };
   let child;
   try { child = spawn(process.env.OCTAVE_BIN || 'octave', ['--quiet','--no-gui',scriptPath], {cwd:dir, windowsHide:true, env:{...process.env, GNUTERM:'pngcairo'}}); }
   catch (e) { finish({ok:false,error:`Could not start GNU Octave: ${e.message}. Install Octave and ensure octave is on PATH.`}); return; }
   child.stdout.on('data', d => { stdout += d.toString(); if (stdout.length > 1_000_000) stdout = stdout.slice(-1_000_000); });
   child.stderr.on('data', d => { stderr += d.toString(); if (stderr.length > 1_000_000) stderr = stderr.slice(-1_000_000); });
   const timer = setTimeout(() => { child.kill('SIGKILL'); finish({ok:false,error:'Execution timed out after 30 seconds. Check for infinite loops or reduce the workload.',stdout,stderr}); }, TIMEOUT_MS);
   child.on('error', e => finish({ok:false,error:`GNU Octave could not start: ${e.message}. Install Octave and ensure octave is on PATH.`,stdout,stderr}));
   child.on('close', code => {
     if (settled) return;
     let plot = null;
     try { if (fs.existsSync(plotPath)) plot = fs.readFileSync(plotPath).toString('base64'); } catch {}
     if (code !== 0) finish({ok:false,error:`Octave exited with code ${code}.`,stdout,stderr,plot});
     else finish({ok:true,stdout,stderr,plot});
   });
 });
}
const server = http.createServer(async (req,res) => {
  if (req.method === 'GET' && req.url === '/api/status') return send(res,200,{ok:true,engine:'GNU Octave',localOnly:true});
  if (req.method === 'POST' && req.url === '/api/run') {
    let body=''; req.on('data',chunk=>{ body += chunk; if (Buffer.byteLength(body)>MAX_BODY) { res.writeHead(413); res.end('Request too large'); req.destroy(); } });
    req.on('end', async()=>{
      let data; try { data=JSON.parse(body); } catch { return send(res,400,{ok:false,error:'Invalid JSON request.'}); }
      if (typeof data.code !== 'string' || !data.code.trim()) return send(res,400,{ok:false,error:'Enter a MATLAB/Octave script first.'});
      if (Buffer.byteLength(data.code)>MAX_BODY) return send(res,413,{ok:false,error:'Script is too large (512 KB maximum).'});
      const result = await runOctave(data.code);
      return send(res,result.ok?200:422,result);
    });
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res,405,{ok:false,error:'Method not allowed.'});
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url,'http://localhost').pathname); } catch { return send(res,400,'Bad request','text/plain'); }
  if (pathname === '/') pathname='/index.html';
  const file = path.resolve(ROOT, '.' + pathname);
  if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT,'index.html')) return send(res,403,'Forbidden','text/plain');
  fs.readFile(file,(err,content)=>{
    if(err) return send(res,404,'Not found','text/plain');
    res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    if(req.method==='HEAD') return res.end();
    res.end(content);
  });
});
server.listen(PORT,HOST,()=>console.log(`SMAT local server: http://${HOST}:${PORT}\nExecution engine: GNU Octave (install separately).\nSecurity: local-only; do not port-forward or expose this service.`));
