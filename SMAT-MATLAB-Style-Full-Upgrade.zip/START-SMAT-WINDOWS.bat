@echo off
setlocal
cd /d "%~dp0"
echo ==========================================
echo SMAT Studio - GNU Octave execution engine
echo ==========================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not on PATH.
  echo Install the Node.js LTS version from https://nodejs.org/ then reopen this file.
  pause
  exit /b 1
)
where octave >nul 2>nul
if errorlevel 1 (
  echo ERROR: GNU Octave is not installed or not on PATH.
  echo Install GNU Octave from https://octave.org/download/ and make sure octave.exe is on PATH.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8080 in your browser.
echo Keep this terminal window open while using SMAT.
node server.js
pause
