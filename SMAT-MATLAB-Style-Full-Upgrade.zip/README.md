# SMAT Studio — MATLAB-style execution upgrade

This package keeps the supplied SMAT Studio UI and replaces its hard-coded demo plot generator with a real local GNU Octave execution backend. GNU Octave is a free, MATLAB-language-compatible numerical computing environment. It is not MathWorks MATLAB and does not support every MATLAB toolbox or product.

## Windows setup
1. Install Node.js LTS: https://nodejs.org/
2. Install GNU Octave: https://octave.org/download/
3. Ensure `node` and `octave` are available in PATH. Reopen Command Prompt after installing.
4. Extract this ZIP, then double-click `START-SMAT-WINDOWS.bat`.
5. Open **http://127.0.0.1:8080** in Chrome/Edge. Keep the terminal window open.
6. Write MATLAB-style code in the editor and click **Execute**. Text output is shown in the command panel; if a figure is created, the first figure is exported and shown in the graph panel.

## Examples supported by GNU Octave
Matrix arithmetic, loops, conditions, functions, vectors/ranges (`1:10`, `0:0.1:10`), `disp`, `fprintf`, `plot`, `plot3`, `meshgrid`, `surf`, `contour`, `bar`, `hist`, and many other core numerical and plotting functions. Exact compatibility depends on the function and installed Octave graphics toolkit/packages.

## Limitations
- This is not a complete clone of MathWorks MATLAB. Proprietary toolboxes, Simulink, MATLAB apps, some newer syntax, and certain functions are unavailable or differ in Octave.
- Graph export requires a working Octave graphics toolkit; install/configure a toolkit such as gnuplot if your Octave installation cannot render figures headlessly.
- Current graph panel shows the first figure found. Multiple figure windows, interactive controls, audio, GUI apps, and live scripts are not fully integrated.
- Script execution has a 30-second timeout and 512 KB request limit.
- **Security:** this backend executes arbitrary code. It binds only to `127.0.0.1`; do not change it to `0.0.0.0`, port-forward it, or expose it publicly. Only run scripts you trust.
